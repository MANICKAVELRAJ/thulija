import {
  Component,
  OnInit,
  AfterViewInit,
  HostListener
} from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import {
  WorksheetLiteService,
  ChartItem
} from './worksheet-lite.service';

@Component({
  selector: 'app-worksheet-lite',
  templateUrl: './worksheet-lite.component.html',
  styleUrls: ['./worksheet-lite.component.css']
})
export class WorksheetLiteComponent implements OnInit, AfterViewInit {

  /* ================= SIDEBAR ================= */
  isSidebarCollapsed = false;

  /* ================= FILE UPLOAD ================= */
  uploadProgress = 0;
  uploadedData: any[] = [];

  /* ================= WORKFLOW ================= */
  defaultWorkflowFields: string[] = [];
  isCustomDataUploaded = false;

  /* ================= PROPERTY PANEL ================= */
  propertyPanelOpen = false;
  selectedItem: ChartItem | null = null;
  editableItem: ChartItem | null = null;
  originalSnapshot: ChartItem | null = null;

  constructor(public service: WorksheetLiteService) {}

  /* ================= INIT ================= */
  ngOnInit(): void {
    this.service.loadCharts();
    this.service.loadWorkflow();

    this.service.workflowFields$.subscribe(fields => {
      this.defaultWorkflowFields = fields;
    });
  }

  ngAfterViewInit(): void {
    const canvas = document.querySelector('.worksheet') as HTMLElement;
    if (canvas) {
      this.service.initCanvas(canvas);
    }
  }

  /* ================= CANVAS ================= */
  dropOnCanvas(event: CdkDragDrop<any>): void {
    this.service.dropOnCanvas(event);
  }

  startMove(event: MouseEvent, index: number): void {
    this.service.startMove(event, index);
  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent): void {
    this.service.moveItem(event);
  }

  @HostListener('document:mouseup')
  stopMove(): void {
    this.service.stopMove();
  }

  /* ================= PROPERTY PANEL ================= */
  openPropertyPanel(chart: ChartItem): void {

    this.selectedItem = chart;

    // 🔥 snapshot for cancel
    this.originalSnapshot = JSON.parse(JSON.stringify(chart));

    // 🔥 editable copy (rounded)
    this.editableItem = {
      ...chart,
      x: Math.round(chart.x ?? 0),
      y: Math.round(chart.y ?? 0),
      width: Math.round(chart.width ?? 0),
      height: Math.round(chart.height ?? 0)
    };

    // 🔥 default workflow fields if no upload yet
    if (!this.editableItem.fields || this.editableItem.fields.length === 0) {
      this.editableItem.fields = [...this.defaultWorkflowFields];
    }

    this.propertyPanelOpen = true;
  }

  saveChanges(): void {
  if (!this.selectedItem || !this.editableItem) return;

  // 🔥 overlap check pannra logic
  const index = this.service.canvasCharts.findIndex(
    c => c.id === this.selectedItem!.id
  );

  if (index !== -1) {
    const [x, y] = this.service.findFreePosition(
      this.editableItem.x!,
      this.editableItem.y!,
      this.editableItem.width!,
      this.editableItem.height!,
      index
    );

    this.editableItem.x = x;
    this.editableItem.y = y;
  }

  Object.assign(this.selectedItem, this.editableItem);
  this.cleanupPropertyPanel();
}


  cancelChanges(): void {
    if (this.selectedItem && this.originalSnapshot) {
      Object.assign(this.selectedItem, this.originalSnapshot);
    }
    this.cleanupPropertyPanel();
  }

  cleanupPropertyPanel(): void {
    this.propertyPanelOpen = false;
    this.selectedItem = null;
    this.editableItem = null;
    this.originalSnapshot = null;
    this.uploadProgress = 0;
  }

  removeChart(id: number): void {
    this.service.removeChart(id);
    if (this.selectedItem?.id === id) {
      this.cleanupPropertyPanel();
    }
  }

  /* ================= FILE UPLOAD ================= */
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;

    const file = input.files[0];
    this.uploadProgress = 0;

    this.service.uploadFile(file, p => {
      this.uploadProgress = p;
    })
    .then(data => {

      this.isCustomDataUploaded = true;
      this.uploadedData = data;

      if (this.editableItem) {
        this.editableItem.data = data;
        this.setFieldsForSelectedChart(data);
      }
    })
    .catch(() => alert('File upload failed'));
  }

  /* ================= FIELD EXTRACTION ================= */
  setFieldsForSelectedChart(data: any[]): void {
    if (!data || data.length === 0 || !this.editableItem) return;

    const fields = Object.keys(data[0]);

    this.editableItem.fields = fields;

    // reset selections
    this.editableItem.valueField = '';
    this.editableItem.xField = '';
    this.editableItem.yField = '';
  }

  /* ================= SIDEBAR ================= */
  toggleSidebar(): void {
    this.isSidebarCollapsed = !this.isSidebarCollapsed;
  }
}
