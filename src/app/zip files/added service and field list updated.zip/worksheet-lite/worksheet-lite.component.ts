import {
  Component,
  AfterViewInit,
  OnInit,
  HostListener
} from '@angular/core';

import { CdkDragDrop } from '@angular/cdk/drag-drop';
import {
  WorksheetLiteService,
  ChartItem,
  WorkflowField
} from './worksheet-lite.service';

@Component({
  selector: 'app-worksheet-lite',
  templateUrl: './worksheet-lite.component.html',
  styleUrls: ['./worksheet-lite.component.css']
})
export class WorksheetLiteComponent implements OnInit, AfterViewInit {

  /* ================= SIDEBAR ================= */
  isSidebarCollapsed = false;

  /* ================= WORKFLOW FIELDS ================= */
  workflowFields: string[] = [];

  /* ================= PROPERTY PANEL ================= */
  propertyPanelOpen = false;
  selectedItem: ChartItem | null = null;

  constructor(public service: WorksheetLiteService) {}

  /* ================= INIT ================= */
  ngOnInit(): void {

    /* Analytics charts */
    this.service.loadCharts();

    /* Workflow fields (Data tab) */
    this.service.loadWorkflowFields().then(keys => {
      this.workflowFields = keys;
    });

  }

  ngAfterViewInit(): void {
    const canvas = document.querySelector('.worksheet') as HTMLElement;
    this.service.initCanvas(canvas);
  }

  /* ================= CANVAS ================= */
  dropOnCanvas(event: CdkDragDrop<any>): void {
    this.service.dropOnCanvas(event);
  }

  startMove(event: MouseEvent, index: number): void {
    this.service.startMove(event, index);
  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent): void {
    this.service.moveItem(event);
  }

  @HostListener('document:mouseup')
  stopMove(): void {
    this.service.stopMove();
  }

  /* ================= PROPERTY PANEL ================= */
  openPropertyPanel(chart: ChartItem): void {
    this.selectedItem = chart;
    this.propertyPanelOpen = true;
  }

  closePropertyPanel(): void {
    this.propertyPanelOpen = false;
    this.selectedItem = null;
  }

  removeChart(id: number): void {
    this.service.removeChart(id);
    if (this.selectedItem?.id === id) {
      this.closePropertyPanel();
    }
  }

  /* ================= UI HELPERS ================= */
  getIconName(type: string): string {
    return this.service.getIconName(type);
  }
}
