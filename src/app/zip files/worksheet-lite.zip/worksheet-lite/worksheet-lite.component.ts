import { Component, HostListener, AfterViewInit, OnInit } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { HttpClient } from '@angular/common/http';

interface ChartItem {
  id: number;
  name: string;
  type: string;
  image?: string;
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  zIndex?: number;
}

@Component({
  selector: 'app-worksheet-lite',
  templateUrl: './worksheet-lite.component.html',
  styleUrls: ['./worksheet-lite.component.css']
})
export class WorksheetLiteComponent implements AfterViewInit, OnInit {

  fields = ['Order Date','Category','Sales','Profit'];
  columns: string[] = [];
  rows: string[] = [];

  chartTypes: ChartItem[] = [];      // loaded from JSON
  canvasCharts: ChartItem[] = [];
  nextId = 1000;                     // unique IDs for canvas charts

  canvasEl!: HTMLElement;

  movingIndex: number | null = null;
  activeIndex: number | null = null;
  offsetX = 0;
  offsetY = 0;
  zIndexCounter = 10;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadCharts();   // load charts from JSON on init
  }

  ngAfterViewInit(): void {
    this.canvasEl = document.querySelector('.worksheet') as HTMLElement;
  }

  /* ================= LOAD CHARTS FROM JSON ================= */
  loadCharts(): void {
    this.http.get<ChartItem[]>('assets/chart.json').subscribe({
      next: (data) => {
        this.chartTypes = data;
      },
      error: (err) => console.error('Failed to load chart.json', err)
    });
  }

  /* ================= SHELF DROP ================= */
  drop(event: CdkDragDrop<any[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      const value = event.previousContainer.data[event.previousIndex];
      if (event.container.data.includes(value)) return;
      transferArrayItem(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex);
    }
  }

  /* ================= DROP CHART TO CANVAS ================= */
  dropOnCanvas(event: CdkDragDrop<any[]>) {
    if (event.previousContainer.id !== 'chartList') return;

    const chart = event.previousContainer.data[event.previousIndex] as ChartItem;
    const rect = this.canvasEl.getBoundingClientRect();
    const e = event.event as MouseEvent;

    this.canvasCharts.push({
      ...chart,
      id: this.nextId++,
      x: e.clientX - rect.left - 80,
      y: e.clientY - rect.top - 60,
      width: 160,
      height: 120,
      zIndex: ++this.zIndexCounter
    });
  }

  /* ================= MANUAL DRAG ================= */
  startMove(event: MouseEvent, index: number): void {
    event.preventDefault();
    event.stopPropagation();

    this.movingIndex = index;
    this.activeIndex = index;

    const item = this.canvasCharts[index];
    item.zIndex = ++this.zIndexCounter;

    this.offsetX = event.offsetX;
    this.offsetY = event.offsetY;
  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent): void {
    if (this.movingIndex === null) return;

    const rect = this.canvasEl.getBoundingClientRect();
    const item = this.canvasCharts[this.movingIndex];

    item.x = event.clientX - rect.left - this.offsetX;
    item.y = event.clientY - rect.top - this.offsetY;

    item.x = Math.max(10, Math.min(item.x, rect.width - (item.width ?? 160) - 10));
    item.y = Math.max(10, Math.min(item.y, rect.height - (item.height ?? 120) - 10));
  }

  @HostListener('document:mouseup')
  stopMove(): void {
    this.movingIndex = null;
    this.activeIndex = null;
  }

  /* ================= Z-INDEX ================= */
  onHover(index: number): void {
    this.canvasCharts[index].zIndex = ++this.zIndexCounter;
  }

  onLeave(): void {
    this.activeIndex = null;
  }

  /* ================= REMOVE ================= */
  removeChart(id: number) {
    this.canvasCharts = this.canvasCharts.filter(c => c.id !== id);
  }
}
