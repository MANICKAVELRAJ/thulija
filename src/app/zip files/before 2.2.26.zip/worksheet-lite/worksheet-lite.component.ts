import {
  Component,
  OnInit,
  AfterViewInit,
  HostListener
} from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import {
  WorksheetLiteService,
  ChartItem
} from './worksheet-lite.service';

@Component({
  selector: 'app-worksheet-lite',
  templateUrl: './worksheet-lite.component.html',
  styleUrls: ['./worksheet-lite.component.css']
})
export class WorksheetLiteComponent implements OnInit, AfterViewInit {

  /* ================= SIDEBAR ================= */
  isSidebarCollapsed = false;

  /* ================= WORKFLOW FIELDS ================= */
  workflowFields: string[] = [];

  /* ================= PROPERTY PANEL ================= */
  propertyPanelOpen = false;
  selectedItem: ChartItem | null = null;       // Actual canvas item
  editableItem: ChartItem | null = null;       // Live preview while editing
  originalSnapshot: ChartItem | null = null;   // Backup for cancel

  /* ================= UPLOAD FLOW ================= */
  uploadOverlayVisible = true;
  selectedFile: File | null = null;
  uploading = false;
  progress = 0;
  uploadError = '';
  uploadCompleted = false;
  tableRows: any[] = [];
  tableHeaders: string[] = [];

  /* ================= DRAG OVER FLAG ================= */
  isDragOver = false;

  constructor(public service: WorksheetLiteService) {}

  /* ================= LIFECYCLE ================= */
  ngOnInit(): void {
    this.service.loadCharts();
  }

  ngAfterViewInit(): void {}

  /* ================= FILE HANDLING ================= */
  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (!file) return;

    const allowed = ['.json', '.xls', '.xlsx'];
    if (!allowed.some(ext => file.name.toLowerCase().endsWith(ext))) {
      alert('Please select JSON or Excel file!');
      return;
    }

    this.selectedFile = file;
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    this.isDragOver = true;
  }

  onDragLeave(event: DragEvent): void {
    this.isDragOver = false;
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.isDragOver = false;
    const file = event.dataTransfer?.files[0];
    if (file) {
      this.onFileSelected({ target: { files: [file] } });
    }
  }

  /* ================= START UPLOAD ================= */
  startUpload(): void {
    if (!this.selectedFile) return;

    this.uploading = true;
    this.uploadCompleted = false;
    this.uploadError = '';
    this.progress = 0;

    this.service.uploadFile(this.selectedFile, (p: number) => {
      this.progress = p;
    })
    .then(data => {
      this.uploading = false;
      this.uploadCompleted = true;

      this.tableRows = data || [];
      this.tableHeaders = data?.length ? Object.keys(data[0]) : [];

      if (this.tableRows.length) {
        this.workflowFields = Object.keys(this.tableRows[0]);
      }

      this.selectedFile = null;
    })
    .catch(err => {
      this.uploading = false;
      this.progress = 0;
      this.uploadError = err;
    });
  }

  /* ================= SKIP UPLOAD ================= */
  skipUpload(): void {
    this.uploadOverlayVisible = false;
    this.workflowFields = [];

    setTimeout(() => {
      const canvas = document.querySelector('.worksheet') as HTMLElement;
      if (canvas) this.service.initCanvas(canvas);
    });
  }

  /* ================= OPEN MAIN PROJECT ================= */
  openProject(): void {
    this.uploadOverlayVisible = false;

    setTimeout(() => {
      const canvas = document.querySelector('.worksheet') as HTMLElement;
      if (canvas) this.service.initCanvas(canvas);
    });
  }

  /* ================= CANVAS DRAG & DROP ================= */
  dropOnCanvas(event: CdkDragDrop<any>): void {
    this.service.dropOnCanvas(event);
  }

  startMove(event: MouseEvent, index: number): void {
    this.service.startMove(event, index);
  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent): void {
    this.service.moveItem(event);
  }

  @HostListener('document:mouseup')
  stopMove(): void {
    this.service.stopMove();
  }

  /* ================= PROPERTY PANEL ================= */
  openPropertyPanel(chart: ChartItem): void {
    this.selectedItem = chart;
    this.originalSnapshot = JSON.parse(JSON.stringify(chart)); // backup for cancel
    this.editableItem = JSON.parse(JSON.stringify(chart));     // live preview
    this.propertyPanelOpen = true;
  }

  saveChanges(): void {
    if (!this.selectedItem || !this.editableItem) return;

    // Commit live preview to actual canvas item
    Object.assign(this.selectedItem, this.editableItem);
    this.cleanupPropertyPanel();
  }

  cancelChanges(): void {
    if (this.selectedItem && this.originalSnapshot) {
      // Revert actual canvas item to original snapshot
      Object.assign(this.selectedItem, this.originalSnapshot);
    }
    this.cleanupPropertyPanel();
  }

  cleanupPropertyPanel(): void {
    this.propertyPanelOpen = false;
    this.selectedItem = null;
    this.editableItem = null;
    this.originalSnapshot = null;
  }

  removeChart(id: number): void {
    this.service.removeChart(id);
    if (this.selectedItem?.id === id) {
      this.cleanupPropertyPanel();
    }
  }

  /* ================= SIDEBAR ================= */
  toggleSidebar(): void {
    this.isSidebarCollapsed = !this.isSidebarCollapsed;
  }

  /* ================= PROGRESS COLOR ================= */
  getProgressColor(): 'primary' | 'accent' | 'warn' {
    if (this.progress < 40) return 'warn';
    if (this.progress < 80) return 'accent';
    return 'primary';
  }
}
