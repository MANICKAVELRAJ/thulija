import { Component, HostListener, AfterViewInit, OnInit } from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { HttpClient } from '@angular/common/http';

interface ChartItem {
  id: number;
  name: string;
  type: string;
  image?: string;
  x?: number;
  y?: number;
  zIndex?: number;
  width?: number;
  height?: number;
}

@Component({
  selector: 'app-worksheet-lite',
  templateUrl: './worksheet-lite.component.html',
  styleUrls: ['./worksheet-lite.component.css']
})
export class WorksheetLiteComponent implements OnInit, AfterViewInit {

  isSidebarCollapsed = false;
  fields = ['Order Date', 'Category', 'Sales', 'Profit'];

  chartTypes: ChartItem[] = [];
  canvasCharts: ChartItem[] = [];

  nextId = 1000;
  zIndexCounter = 10;

  canvasEl!: HTMLElement;
  movingIndex: number | null = null;
  offsetX = 0;
  offsetY = 0;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadCharts();
  }

  ngAfterViewInit(): void {
    this.canvasEl = document.querySelector('.worksheet') as HTMLElement;
  }

  toggleSidebar(): void {
    this.isSidebarCollapsed = !this.isSidebarCollapsed;
  }

  loadCharts(): void {
    this.http.get<ChartItem[]>('assets/chart.json').subscribe(data => {
      this.chartTypes = data;
    });
  }

  /* ================= DROP ================= */
  dropOnCanvas(event: CdkDragDrop<any>): void {
    if (event.previousContainer.id !== 'chartList') return;

    const draggedChart = event.item.data as ChartItem;
    const rect = this.canvasEl.getBoundingClientRect();
    const mouse = event.event as MouseEvent;

    const canvasWidth = this.canvasEl.clientWidth;

    const width = Math.max(150, Math.min(220, canvasWidth * 0.18));
    const height = width * 0.75;

    let x = mouse.clientX - rect.left - width / 2;
    let y = mouse.clientY - rect.top - height / 2;

    [x, y] = this.findFreePosition(x, y, width, height);

    this.canvasCharts.push({
      ...draggedChart,
      id: this.nextId++,
      x,
      y,
      width,
      height,
      zIndex: ++this.zIndexCounter
    });
  }

  /* ================= SMART ANTI OVERLAP ================= */
  findFreePosition(
    x: number,
    y: number,
    width: number,
    height: number,
    ignoreIndex: number | null = null
  ): [number, number] {

    const padding = 16;
    const maxRadius = 350;

    x = Math.max(0, Math.min(x, this.canvasEl.clientWidth - width));
    y = Math.max(0, Math.min(y, this.canvasEl.clientHeight - height));

    const cx = x;
    const cy = y;

    for (let r = 0; r <= maxRadius; r += 20) {
      for (let a = 0; a < 360; a += 30) {

        const rad = a * Math.PI / 180;
        const nx = cx + r * Math.cos(rad);
        const ny = cy + r * Math.sin(rad);

        if (
          nx < 0 || ny < 0 ||
          nx + width > this.canvasEl.clientWidth ||
          ny + height > this.canvasEl.clientHeight
        ) continue;

        let overlap = false;

        for (let i = 0; i < this.canvasCharts.length; i++) {
          if (ignoreIndex === i) continue;

          const c = this.canvasCharts[i];
          if (!c.x || !c.y || !c.width || !c.height) continue;

          const hit = !(
            nx + width + padding < c.x ||
            nx > c.x + c.width + padding ||
            ny + height + padding < c.y ||
            ny > c.y + c.height + padding
          );

          if (hit) {
            overlap = true;
            break;
          }
        }

        if (!overlap) return [nx, ny];
      }
    }

    return [x, y];
  }

  /* ================= MOVE ================= */
  startMove(event: MouseEvent, index: number): void {
    this.movingIndex = index;
    const item = this.canvasCharts[index];
    item.zIndex = ++this.zIndexCounter;

    this.offsetX = event.offsetX;
    this.offsetY = event.offsetY;
  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent): void {
    if (this.movingIndex === null) return;

    const rect = this.canvasEl.getBoundingClientRect();
    const item = this.canvasCharts[this.movingIndex];

    let x = event.clientX - rect.left - this.offsetX;
    let y = event.clientY - rect.top - this.offsetY;

    x = Math.max(0, Math.min(x, this.canvasEl.clientWidth - item.width!));
    y = Math.max(0, Math.min(y, this.canvasEl.clientHeight - item.height!));

    item.x = x;
    item.y = y;
  }

  /* ================= SNAP SAFE ================= */
  @HostListener('document:mouseup')
  stopMove(): void {
    if (this.movingIndex === null) return;

    const item = this.canvasCharts[this.movingIndex];
    const [x, y] = this.findFreePosition(
      item.x!, item.y!, item.width!, item.height!, this.movingIndex
    );

    item.x = x;
    item.y = y;
    this.movingIndex = null;
  }

  onHover(index: number): void {
    if (this.movingIndex !== index) {
      this.canvasCharts[index].zIndex = ++this.zIndexCounter;
    }
  }

  removeChart(id: number): void {
    this.canvasCharts = this.canvasCharts.filter(c => c.id !== id);
  }
}
