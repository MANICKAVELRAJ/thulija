import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CdkDragDrop } from '@angular/cdk/drag-drop';

/* ================= CHART ================= */
export interface ChartItem {
  id: number;
  name: string;
  type: string;
  image?: string;
  x?: number;
  y?: number;
  zIndex?: number;
  width?: number;
  height?: number;
}

/* ================= WORKFLOW (MATCH JSON) ================= */
export interface WorkflowField {
  id: number;
  name: string;

  input_property_value?: string;
  output_property_value?: string;
  execute?: string;
}

@Injectable({
  providedIn: 'root'
})
export class WorksheetLiteService {

  /* ================= DATA ================= */
  chartTypes: ChartItem[] = [];
  canvasCharts: ChartItem[] = [];
  workflowFieldKeys: string[] = [];

  /* ================= CANVAS ================= */
  nextId = 1000;
  zIndexCounter = 10;

  canvasEl!: HTMLElement;
  movingIndex: number | null = null;
  offsetX = 0;
  offsetY = 0;

  constructor(private http: HttpClient) {}

  /* ================= INIT ================= */
  initCanvas(el: HTMLElement): void {
    this.canvasEl = el;
  }

  /* ================= LOAD CHARTS ================= */
  loadCharts(): Promise<ChartItem[]> {
    return this.http
      .get<ChartItem[]>('assets/chart.json')
      .toPromise()
      .then(res => {
        this.chartTypes = res || [];
        return this.chartTypes;
      });
  }

  /* ================= LOAD WORKFLOW JSON ================= */
  loadWorkflowFields(): Promise<string[]> {
    return this.http
      .get<any[]>('assets/workflowprocess.json')
      .toPromise()
      .then(res => {

        if (res && res.length > 0) {
          // 👇 dictionary keys only
          this.workflowFieldKeys = Object.keys(res[0]);
        } else {
          this.workflowFieldKeys = [];
        }

        return this.workflowFieldKeys;
      });
  }

  /* ================= DROP ================= */
  dropOnCanvas(event: CdkDragDrop<any>): void {
    if (event.previousContainer.id !== 'chartList') return;

    const draggedChart = event.item.data as ChartItem;
    const rect = this.canvasEl.getBoundingClientRect();
    const mouse = event.event as MouseEvent;

    const width = 180;
    const height = 140;

    let x = mouse.clientX - rect.left - width / 2;
    let y = mouse.clientY - rect.top - height / 2;

    [x, y] = this.findFreePosition(x, y, width, height);

    this.canvasCharts.push({
      ...draggedChart,
      id: this.nextId++,
      x,
      y,
      width,
      height,
      zIndex: ++this.zIndexCounter
    });
  }

  /* ================= OVERLAP ================= */
  findFreePosition(
    x: number,
    y: number,
    width: number,
    height: number,
    ignoreIndex: number | null = null
  ): [number, number] {

    const padding = 16;

    x = Math.max(0, Math.min(x, this.canvasEl.clientWidth - width));
    y = Math.max(0, Math.min(y, this.canvasEl.clientHeight - height));

    for (let i = 0; i < 200; i++) {
      let overlap = false;

      for (let j = 0; j < this.canvasCharts.length; j++) {
        if (ignoreIndex === j) continue;

        const c = this.canvasCharts[j];
        const hit = !(
          x + width + padding < c.x! ||
          x > c.x! + c.width! + padding ||
          y + height + padding < c.y! ||
          y > c.y! + c.height! + padding
        );

        if (hit) {
          overlap = true;
          x += padding;
          y += padding;
          break;
        }
      }
      if (!overlap) break;
    }
    return [x, y];
  }

  /* ================= MOVE ================= */
  startMove(event: MouseEvent, index: number): void {
    this.movingIndex = index;
    const item = this.canvasCharts[index];
    item.zIndex = ++this.zIndexCounter;
    this.offsetX = event.offsetX;
    this.offsetY = event.offsetY;
  }

  moveItem(event: MouseEvent): void {
    if (this.movingIndex === null) return;

    const rect = this.canvasEl.getBoundingClientRect();
    const item = this.canvasCharts[this.movingIndex];

    item.x = Math.max(
      0,
      Math.min(
        event.clientX - rect.left - this.offsetX,
        this.canvasEl.clientWidth - item.width!
      )
    );

    item.y = Math.max(
      0,
      Math.min(
        event.clientY - rect.top - this.offsetY,
        this.canvasEl.clientHeight - item.height!
      )
    );
  }

  stopMove(): void {
    if (this.movingIndex === null) return;

    const item = this.canvasCharts[this.movingIndex];
    const [x, y] = this.findFreePosition(
      item.x!,
      item.y!,
      item.width!,
      item.height!,
      this.movingIndex
    );

    item.x = x;
    item.y = y;
    this.movingIndex = null;
  }

  /* ================= HELPERS ================= */
  removeChart(id: number): void {
    this.canvasCharts = this.canvasCharts.filter(c => c.id !== id);
  }

  getIconName(type: string): string {
    return type?.toLowerCase().includes('column')
      ? 'bar_chart'
      : 'stacked_bar_chart';
  }
}
