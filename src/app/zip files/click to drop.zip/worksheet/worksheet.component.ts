import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export interface ChartItem {
  id: number;
  name: string;
  image: string;
}

export interface CanvasItem extends ChartItem {
  x: number;
  y: number;
}

@Component({
  selector: 'app-worksheet',
  templateUrl: './worksheet.component.html',
  styleUrls: ['./worksheet.component.css']
})
export class WorksheetComponent implements OnInit {

  fields: ChartItem[] = [];
  canvasItems: CanvasItem[] = [];

  draggingItem: ChartItem | null = null;
  offsetX = 0;
  offsetY = 0;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadCharts();
  }

  loadCharts(): void {
    this.http.get<ChartItem[]>('assets/chart.json').subscribe({
      next: (data) => this.fields = data,
      error: (err) => console.error('Failed to load chart.json', err)
    });
  }

  startDrag(event: MouseEvent, field: ChartItem) {
    this.draggingItem = field;
    this.offsetX = event.offsetX;
    this.offsetY = event.offsetY;
  }

  dropOnCanvas(event: MouseEvent) {
    if (!this.draggingItem) return;

    const rect = (event.target as HTMLElement).getBoundingClientRect();
    const x = event.clientX - rect.left - this.offsetX;
    const y = event.clientY - rect.top - this.offsetY;

    // Add a copy of the item to canvas with position
    this.canvasItems.push({
      ...this.draggingItem,
      x: x,
      y: y
    });

    this.draggingItem = null;
  }

  removeCanvasItem(index: number) {
    this.canvasItems.splice(index, 1);
  }
}
